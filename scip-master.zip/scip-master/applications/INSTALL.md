Building and installing the applications                       {#INSTALL_APPLICATIONS}
========================================

Please see the file `INSTALL_APPLICATIONS_EXAMPLES.md` in the SCIP main directory.
