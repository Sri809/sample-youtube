Building and installing the Coloring application
================================================

Please refer to the INSTALL_APPLICATIONS_EXAMPLES.md file in the scip directory.
