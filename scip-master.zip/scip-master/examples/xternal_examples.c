/** @dir ../examples
 *  @brief this directory contains all coding examples, see \ref EXAMPLES for more information.
 */