Building and installing the GMI example
================================================

Please refer to the INSTALL_APPLICATIONS_EXAMPLES.md file in the scip directory.
