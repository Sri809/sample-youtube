Building and installing the examples      {#INSTALL_EXAMPLES}
====================================

Please see the file `INSTALL_APPLICATIONS_EXAMPLES.md` in the SCIP main directory.
